using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;

namespace AvaloniaApplication2
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }

    public class MyToggleButton : ToggleButton
    {
        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (IsFocused)
            {
                base.OnKeyDown(e);
            }
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            if (IsFocused)
            {
                base.OnKeyUp(e);
            }
        }
    }
}